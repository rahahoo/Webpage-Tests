package NegativeTests;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.DashboardPage;
import pages.HomePage;
import utils.Browser;

public class NegativeDashboardPageTest {
    @BeforeMethod
    public void setup() {
        Browser.setUp();
    }
    @AfterMethod
    public void quit() {
        Browser.quit();
    }
    @Test
    public void dashboardOpenTest() {
        HomePage.goToDashboardPage();
    }
    @Test
    public void menuToggle() {
        DashboardPage.MenuToggleButton();
    }
    @Test
    public void searchField() {
        DashboardPage.SearchField();
    }
    @Test
    public void NegativeDashboardSearchFieldSubmit() {
        DashboardPage.DashboardSearchFieldSubmit();
    }
    @Test
    public static void searchSubmit() {
        DashboardPage.SearchSubmit();
    }
}
