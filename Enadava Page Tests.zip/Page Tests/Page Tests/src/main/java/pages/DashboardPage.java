package pages;


import org.openqa.selenium.By;
import org.testng.Assert;
import utils.Browser;

public class DashboardPage {

    private static final By ConfirmationMessage = By.xpath("//*[@id=\"hero-contentcarousel\"]/div[1]/div/div/div/div/div/h2");
    private static final By MenuToggleButton = By.xpath("//a[@id=\"menu-toggle\"]");
    private static final By SearchField = By.xpath("//input[@id='search-input']");
    private static final By SearchSubmit = By.cssSelector("input[id='searchSubmit']");
    private static final By SearchResultsConfirmation =By.cssSelector("div[class='search-result-lists pos-rel']");

    public static void Confirmation() {
        String ActualText = Browser.driver.findElement(ConfirmationMessage).getText();
        Assert.assertEquals("Welcome to Endava",ActualText);
    }
    public static void MenuToggleButton() {
        Browser.driver.findElement(MenuToggleButton).click();
    }
    public static void SearchField() {
        Browser.driver.findElement(SearchField).click();
    }
    public static void DashboardSearchFieldSubmit() {
        Browser.driver.findElement(SearchField).sendKeys("endavaendavaendavaendavaendavaendavaendavaendavaendavaendavaendavaendavaendavaendavaendavaendavaendavaendavaendavaendavaendavaen");
    }
    public static void NegativeDashboardSearchFieldSubmit() {
        Browser.driver.findElement(SearchField).sendKeys("!@#$%^&*()_!@#$%^&*()_!@#$%^&*()_!@#$%^&*()_!@#$%^&*()_!@#$%^&*()_!@#$%^&*()_!@#$%^&*()_!@#$%^&*()_!@#$%^&*()_!@#$%^&*()_!@#$%^&*");
    }
    public static void SearchSubmit() {
        Browser.driver.findElement(SearchSubmit).click();
    }
    public static void SearchResultsConfirmation() {
        String ActualSearchResultsText = Browser.driver.findElement(SearchResultsConfirmation).getText();
        Assert.assertEquals("There are no results for your search criteria.",ActualSearchResultsText);
    }

}
