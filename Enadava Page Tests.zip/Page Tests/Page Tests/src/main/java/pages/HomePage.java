package pages;

import org.openqa.selenium.By;
import utils.Browser;

public class HomePage {

    public static void goToPage(){
        Browser.driver.get("https://www.endava.com/");
    }
    public static By dashboardBannerButton = By.xpath("//*[@id=\"hero-contentcarousel\"]/div[1]/div/div[1]/div/div[1]/div/h2/a");

    public static void dashboardOpener() {
        Browser.driver.findElement(dashboardBannerButton).click();
    }
    public static void goToDashboardPage() {
        Browser.driver.get("https://www.endava.com/en/About");
    }

}
